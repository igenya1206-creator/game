const costumes = [
  { id: "battle", label: "バトルスーツ" },
  { id: "school", label: "スクール＆ルーズソックス" },
  { id: "nurse", label: "ナース" },
  { id: "maid", label: "メイド" },
  { id: "witch", label: "ウィッチ" },
  { id: "suit", label: "ミニスカスーツ" },
  { id: "bunny", label: "バニー" }
];

const hairs = [
  { id: "long", label: "ロング" },
  { id: "short", label: "ショート" },
  { id: "twin", label: "ツイン" },
  { id: "ponytail", label: "ポニー" }
];

const state = {
  costume: "battle",
  hair: "long",
  skirt: 28,
  bust: 150,
  waist: 50,
  hip: 100
};

const actor = document.getElementById("actor");
const cineActor = document.getElementById("cineActor");
const costumeChips = document.getElementById("costumeChips");
const hairChips = document.getElementById("hairChips");

function mapRange(value, inMin, inMax, outMin, outMax) {
  return outMin + ((value - inMin) * (outMax - outMin)) / (inMax - inMin);
}

function applyTo(el) {
  el.className = `actor costume-${state.costume} hair-${state.hair}`;
  el.style.setProperty("--bust", mapRange(state.bust, 70, 160, 0.85, 1.55).toFixed(3));
  el.style.setProperty("--waist", mapRange(state.waist, 46, 78, 0.92, 0.62).toFixed(3));
  el.style.setProperty("--hip", mapRange(state.hip, 80, 120, 0.95, 1.38).toFixed(3));
  el.style.setProperty("--skirt", `${state.skirt}%`);
}

function syncLabels() {
  const costume = costumes.find((c) => c.id === state.costume);
  document.getElementById("costumeLabel").textContent = costume.label;
  document.getElementById("specLine").textContent =
    `SKIRT ${state.skirt}% · HAIR ${state.hair.toUpperCase()} · B${state.bust} / W${state.waist} / H${state.hip}`;
  document.getElementById("bustVal").textContent = `${state.bust}cm`;
  document.getElementById("waistVal").textContent = `${state.waist}cm`;
  document.getElementById("hipVal").textContent = `${state.hip}cm`;
}

function render() {
  applyTo(actor);
  syncLabels();
}

function makeChips(root, items, key) {
  root.innerHTML = "";
  items.forEach((item) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `chip${state[key] === item.id ? " active" : ""}`;
    btn.textContent = item.label;
    btn.addEventListener("click", () => {
      state[key] = item.id;
      [...root.children].forEach((c) => c.classList.remove("active"));
      btn.classList.add("active");
      render();
    });
    root.appendChild(btn);
  });
}

makeChips(costumeChips, costumes, "costume");
makeChips(hairChips, hairs, "hair");

document.getElementById("skirt").addEventListener("input", (e) => {
  state.skirt = Number(e.target.value);
  render();
});
document.getElementById("bust").addEventListener("input", (e) => {
  state.bust = Number(e.target.value);
  render();
});
document.getElementById("waist").addEventListener("input", (e) => {
  state.waist = Number(e.target.value);
  render();
});
document.getElementById("hip").addEventListener("input", (e) => {
  state.hip = Number(e.target.value);
  render();
});

document.getElementById("deploy").addEventListener("click", () => {
  const costume = costumes.find((c) => c.id === state.costume);
  applyTo(cineActor);
  cineActor.classList.add("enter");
  document.getElementById("cineTitle").textContent = costume.label;
  document.getElementById("cineSpec").textContent =
    `175cm · 65kg · B${state.bust} / W${state.waist} / H${state.hip}`;
  document.getElementById("app").hidden = true;
  document.getElementById("cinematic").hidden = false;
});

document.getElementById("back").addEventListener("click", () => {
  cineActor.classList.remove("enter");
  document.getElementById("cinematic").hidden = true;
  document.getElementById("app").hidden = false;
});

window.addEventListener("load", () => {
  render();
  setTimeout(() => {
    document.getElementById("boot").style.display = "none";
    document.getElementById("app").hidden = false;
  }, 1600);
});
